/*Name: Ismail Mare
 *  ID: 1388973
 *  LECTURE SECTION: B1
 *  UNIX ID: imare
 *  INSTRUCTOR: Smith Jaqueline
 *  LAB SECTION: H02
 *  TA'S NAME: Nicholas Barriga
 */


#ifndef __Lunar_Lander__draw__
#define __Lunar_Lander__draw__


# define PROG_LEN 128 // Length of program length

# define LINE_LEN 256 // Max length of line

#define PAUSE_LEN 5 // Length of pause instruction

# define IMAGE_LEN 4

#define PI acos(-1.0)




#endif /* defined(__Lunar_Lander__draw__) */

